Trumpet Playing Robot
=====================

Read [the blog post](https://medium.com/@urish/we-tried-to-build-a-robot-that-plays-the-trumpet-and-happily-failed-c9ca1d6063b8) for more info.
